=== TWD Site Kit ===
Contributors: therapywebdesigns
Tags: pages, design, styles, therapist
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 0.18.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Pages for therapist sites built from sanitised HTML and a fixed set of components, with version history, style packs and bundled fonts.

== Description ==

TWD Site Kit stores a page as cleaned HTML made from a fixed set of components, keeps the last ten versions of each page, and shows it with the [twd_page] shortcode. Two style packs (sage and grove) set the colours, fonts and shapes. Fonts are bundled, so a site makes no requests to Google Fonts.

It is a sibling to the Articles and Resource Production Plugin, and is updated from the plugin's own public repository on GitHub, not from WordPress.org. Every update is checked against a sha256 checksum before it is installed.

== Installation ==

1. In WordPress go to Plugins, Add New Plugin, Upload Plugin.
2. Choose the zip and click Install Now, then Activate Plugin.

== Changelog ==

= 0.18.0 =
* New: write search titles and descriptions with the AI. In the Site tab, Search wording with AI finds the pages that have none, drafts each one from the page's own words, your saved facts and your keywords, and lets you read and change them before you save. A page's own Search tab can also write for one page. The AI never saves anything and never replaces wording you already have unless you tick that.
* New: a featured picture for each page, in the Search tab. A page with no picture for sharing now shares its featured picture, then the site's default.
* New: in the simple editor's Page details, clients can choose the picture shown when the page is shared and the featured picture. These save straight away and are not part of Undo.
* Nothing changes how a site looks until these are used. The AI features need the AI key from the Articles plugin. Update one site first.

= 0.17.3 =
* Export for an AI now holds the whole of a page's search setup (social share picture and keep-out-of-search, as well as title and description), a file of the site-wide search settings, a list of every picture used (where, description, size, whether the file is there, and what is wrong), and the results of the site's own launch check.
* New tick in Export for an AI: include small copies of the pictures, so an AI that can look at images can see which photo is which. A bigger download, off by default. On the command line: wp twd-sk export_site --pictures.
* Nothing else changes.

= 0.17.2 =
* Export for an AI is easier for an AI to follow: each page's search title and description are in the page index, there is a guide to the kit sections the pages use, a worked example reply made from the site's own words (it changes nothing), and the README now lists what must never be touched, a check to make before replying, and to send the most important changes first.
* Changes from an AI: after a check that refused something, Copy the problems for the AI puts the reasons in a ready-to-paste message, so the AI can fix just those.
* Nothing else changes.

= 0.17.1 =
* Export for an AI now also holds the plugin's own style rules for the sections a page uses (site/kit-stylesheet-used.css), so an AI can read how every section looks. A draft page no longer shows a made-up address in the export. The README tells the AI what it can and cannot judge from code, to ignore drafts, and to prefer find and replace on pages that are one large custom section. Nothing else changes.

= 0.17.0 =
* New: Export for an AI. In the Site tab, download the whole site, one page, or the header and footer as one zip an AI can read, with your own notes and a README that tells the AI how to reply. Useful when an AI cannot reach the site itself.
* New: Changes from an AI. Paste the AI's reply, see each change with its before and after words, untick any you do not want, then apply. Each page becomes one new version, so Undo works page by page. A reply that does not follow the format is refused with a reason.
* New: Footer HTML. When the footer is a saved HTML embed, edit it in the Site tab (or from the Edit footer button over it), save it, and copy a prompt with the code to remix it with an AI.
* Nothing changes how a site looks until these are used. Update one site first.

= 0.16.1 =
* Fix: in the Visual editor, setting a new address on a link that is not a Site Kit button (for example a button in a custom section) now saves. Before, Set the link looked done but the old address stayed. Nothing else changes.

= 0.16.0 =
* A large update. Nothing here changes how a site looks until a setting is chosen: a site that updates and changes nothing looks as before. Update one site first and look at it.
* New: social buttons. WhatsApp, Facebook, Instagram and YouTube buttons with their icons, drawn by the plugin when the page is shown, and a Social links section (a normal row or round icon-only buttons). Links must be https and on the network's own address, and the sample links must be replaced before a page can be published.
* New: one Your Edits window for editing on the page (compact and grouped, it follows what you click), a simpler editor for clients, a Look panel for each section, shared text styles, Add, Move and Delete a section, Undo and Redo with a history of site changes, Page details and Footer words for clients.
* New: the Embed section, Replace this section with custom HTML and CSS, Describe a change with the AI, Import a page, Export a page, and the site's own stylesheet with a panel in the Site tab (budget 40 KB, warning from 32 KB).
* New: the Snag button, an administrator's own list of faults and wants.
* New: a two-row text header, a second line in the smaller header, up to 10 links in a sub-menu with its own dropdown look settings, a footer taken from a saved HTML embed, and pictures that load at the right size for the screen.
* Safe mode and Undo are unchanged. To go back: put the previous version of the plugin back, or turn on safe mode with `wp twd-sk safe-mode on`.

= 0.14.1 =
* A larger update. Nothing here is on by default: a site that updates and changes nothing looks exactly as before. Update one site first and look at it.
* New: a large footer layout (`feature`). The logo large, the footer text as a heading, a Contact label with the email, phone and address, the registration lines, the page links in two columns, and a slim dark strip below with only the copyright and the legal links. Choose it in the Site tab, Header and footer, or with `wp twd-sk style apply --footer=feature`. Its logo sizes are their own settings, so the other footers do not change.
* New: a text wordmark header, off until ticked in the Site tab. The logo as live text: on the front page a centred stack (a small symbol, the site name in capitals, an optional second line, the menu below), on every other page one row (symbol and name at the left, menu at the right), and a compact row when scrolled. The menu gets its own smaller look (capitals, 13px by default, all set by tokens), and the page you are on is marked by a small dot instead of an underline (or colour, a short bar or nothing). Also in a style kit, the site brief and `wp twd-sk style apply --wordmark`.
* New style packs: Ink (text-led, off-white and black with one blue-green), Ember (warm editorial) and Midnight (bold modern). Eight more bundled fonts (EB Garamond, Inter, Source Serif 4, Work Sans, Nunito Sans, DM Sans, Fraunces, Playfair Display), still with no request to any font service.
* Logo sizes in the Site tab (header, phone, front page, footer). An option for a bigger logo on the front page with a small logo mark on other pages. An option for a transparent header over a page that opens with a full-width picture.
* New layouts: question groups, prose text, an articles strip (a few articles from one category beside an introduction), a parallax picture hero (still on phones and for reduced motion) with overlay and alignment options, services as linked rows, steps as a timeline, questions in two columns, a logos grid, hours in a card, areas split.
* Restyle: style kits. `wp twd-sk style apply <pack> [--header=] [--footer=] [--dry-run]` lists every change, checks contrast, keeps a snapshot and never touches a page's words or pictures; `wp twd-sk style revert` puts the old look back; `wp twd-sk style swap` moves a kind of section between layouts. An administrator can preview a pack with ?twd_sk_style=PACK without saving.
* Visual editor: Remove and Put back for a list entry, card, button or whole section (never the first hero or the safety notice); a placeholder marker is edited as one unit.
* Launch check: every menu link must reach a page; WordPress's own sample page, first post and suggested privacy text are flagged, with a Tidy up button that bins them; half a placeholder marker and the words TO CONFIRM count as must-fix; the Articles plugin must be active (older than 1.42.0 warns) where a page shows the grid.
* Publishing a kit page from wp-admin while example text remains keeps it a draft with a notice and a "publish it anyway" link. A notice on a kit page's edit screen says where it is edited.
* Full site set up: "Build a draft anyway" when questions are still open; each gap becomes a visible marker.
* One skip link on the Hello theme. Unknown layouts in a brief fall back to the standard one with a warning. `wp twd-sk save --pictures` places pictures by name.
* `wp twd-sk style apply` can change only the header or footer layout (`--header`, `--footer`, `--wordmark`, `--scrolled-name`, `--menu-marker`) with no pack name.
* Fixed: the less-motion setting now really stops the fixed header's size change on scroll. A style snapshot now also keeps the transparent header setting, so a revert restores it.

= 0.13.0 =
* New: Shrink on scroll. A tick box in the Site tab, Header and footer ("Make the fixed header smaller when scrolling"), off by default. With it on and the header fixed at the top, the header gets a little smaller (smaller logo, less space above and below) after a short scroll and returns to full size at the top. The page never moves when it changes size.
* A tiny script (about 40 lines) does this and loads only when the box is ticked and the header is fixed. Without it the header is just a normal fixed header. Nothing animates for visitors who ask for reduced motion. Also in the site brief as header.shrink. Off in safe mode.
* The header logo height now comes from one stylesheet variable, ready for a logo size setting later.

= 0.12.0 =
* New (test option): Full site set up. Paste everything you have in one box. The AI says what is still missing and asks any design questions (look, tone of voice, photos), and the site is built only when nothing is missing.
* Pages are written only from what you supply. A fact the notes do not support is left out rather than marked as missing. The only places left to fill in are photos: each photo spot says what is wanted and gives a Pexels search to start from, and you upload the photo in the Visual editor. Or choose no photos, and the pages are built with layouts that have no photo spots.
* The page list is Home, About, one page for each thing you offer, Questions and answers, Resources (when the Articles plugin is active) and Contact. The email is yours, or info@ on your site address if you gave none. No phone number is shown unless you give one.
* Every written page is checked afterwards: any email, phone number or price that is not in your notes is listed for you to look at. Pages are drafts and nothing is published.
* Needs the AI key from the Articles plugin. Off unless ticked on the first step of Set up site.

= 0.11.0 =
* New: Tell us. A button for anyone who can edit pages. They write what they would like changed, and the note is kept on your own site as text, then deleted after the time you choose (12 months unless you change it). Off until you switch it on in the Site tab.
* New: an administrator sees every note, can mark it new, seen, done or parked, add private ideas, and copy the new notes as markdown.
* New: wp twd-sk snags prints the notes, wp twd-sk snag-status changes one, wp twd-sk snags-setting switches the module.
* New: an optional email saying a note has arrived. It never contains the note.
* New: signed-in editors see a small version label in the bottom left corner, so a phone showing an old cached copy is easy to spot.
* Changed: Edit text is now called Visual editor.
* Safe mode switches Tell us off. Notes are never sent anywhere else.

= 0.10.2 =
* Changed: the Edit text toolbar is now a compact card at the bottom left, so it no longer covers buttons from other plugins at the bottom right (such as New Article). On a phone it spans the screen.
* New: the WordPress admin bar has Edit text, which becomes Save changes and Cancel while you edit.

= 0.10.1 =
* New: in Edit text, a place the AI marked for a picture (such as [PLACEHOLDER: image needed]) shows as an Add a picture box. Click it to put a picture there.
* New: every picture can come from the media library or be uploaded straight from your computer.
* New: change a picture's description on its own, without swapping the picture.

= 0.10.0 =
* New: Edit text. Change words, links and pictures right on the page, with bold, italic and link buttons. Only the changed pieces are saved, as a new version you can undo. No AI needed.
* New: one box in Edit with AI. Write what you want changed (one line or a list), get a checklist to untick from, then the changes are made one at a time and shown in the preview before anything is saved. It says plainly what a page cannot do, and uses any wording you paste word for word.
* New sections: boxes with a softly moving border in the site's colours, and a testimonial slider (swipe, arrows and dots; nothing moves on its own). Both respect reduced motion.
* The separate section picker, extra facts box and Add a section panel are replaced by the one box.

= 0.9.3 =
* New: Choose the brief file on the setup page reads the .json file itself, so nothing is lost in copy and paste.
* New: the facts in a brief can be a list of short lines.
* Fixed: a brief that cannot be read now says where (the line, or that it was cut short, or curly quotes), and Build waits until it is fixed instead of building without it.
* Fixed: building again updates the menu and header button the setup made itself (never ones you changed), moves the about link to the new about page, and lists pages from an earlier build that are no longer planned. Pages in the bin are made again.
* The logo slot now says it is the header and footer logo, and shows the whole logo.

= 0.9.2 =
* Fixed: a long site brief or page no longer fails with "The AI ran out of room". Pages with more than six sections are written a few sections at a time, and any part that is still too long is split and tried again.
* Fixed: pasting a site brief and pressing "Turn my notes into a brief (AI)" now just checks the brief, with no AI call.
* Long notes are kept as the facts word for word, so the AI only writes the rest of the brief.
* Ask the AI: when a change is too big for one go, it says to choose fewer sections.

= 0.9.1 =
* New: on the Hello theme Site Kit places the header and footer itself, so Elementor Pro is not needed. Hello's own basic header and footer are switched off, and a Skip to content link comes first.
* New: Site tab, Header and footer, Who places them: Site Kit (default) or Elementor Pro templates. An Elementor Pro header or footer template still takes over on the pages it covers.
* Safe: in safe mode, on another theme, on Elementor Canvas pages, or if the setting cannot be read, Site Kit stands aside and Hello's own header and footer show.
* The launch check, the site report and the build report say who places the header and footer.

= 0.9.0 =
* New: the launch check. One list of everything worth checking before a site goes live: example text still to replace on each page, search wording, the front page, the privacy policy, the site details, the enquiry form, search engines allowed, https, the header and footer, and the support lines to check by hand. Each item says Fix, Look or OK. The setup page's new Launch step publishes the pages that are ready (never one with anything left to replace). Also in the Site tab, in the site report, and as wp twd-sk launch-check.

= 0.8.4 =
* New: starting points for the setup page. On the first step, choose the kind of site (for example counselling, coaching, mobile hire, trades, or a studio with classes) to start from a ready list of pages and sections. A brief that lists its own pages still wins, and the Pages step can change everything before building. Also wp twd-sk build --set=<name>.

= 0.8.3 =
* New: keep in view. Choose which part of a picture stays visible when a kit page crops it (for example Top for a face), in the media library's edit screen or on the setup page's Pictures step. It applies to every page that uses the picture.

= 0.8.2 =
* New: colours from the logo. In the Site tab's Style section, Take colours from the logo previews the buttons, headings, bands and accents in the logo's main colours. Nothing is kept until you press Save style. The setup page has a matching tick box, and wp twd-sk brand does the same from the command line. Every colour is checked so text stays easy to read; any that would not be is left as the style's own.

= 0.8.1 =
* New: an Enquiry form section. A simple form (name, email, optional phone, message and a consent tick) that emails the address in the site details, or the WordPress admin email. It has a hidden spam trap, a signed check that works with page caching, and limits per visitor and per day. Nothing about a message is stored on the site; the site report shows counts only. Add it with Add a section or in the setup page's Pages step.

= 0.8.0 =
* New sections: Pictures (a grid of pictures with captions, three or two across), Logos strip (accreditations, memberships or partners), Prices (cards, or a simple list of names and prices), Opening hours, and Areas covered (a list of areas with a button to a map). They can be chosen in the setup page's Pages step and with Add a section, and the AI can use them. Their sample wording is flagged until it is replaced.

= 0.7.3 =
* New: Add a section, in the Edit with AI pop-up. Choose where it goes, the kind of section and its layout, and (when the site has an AI key) let the AI write it from the facts. You see a preview first, and nothing is saved until you apply it. Without a key the section arrives with [PLACEHOLDER] wording to fill in.

= 0.7.2 =
* New: a Pages step in the setup page, before pictures and building. See every page that will be made, change the order and titles, add or remove pages, and choose the sections on each page (add, remove, reorder, pick a layout). Nothing is spent or made until you build.
* New: a site brief's pages can list their own sections.

= 0.7.1 =
* New: the setup page. On a fresh site an administrator sees a Set this site up link on the front page, which opens Settings, Set up site: choose the site type and style, paste a site brief or plain notes (the AI can turn notes into a brief for you to check), choose pictures from the media library (logo, Home picture, About photo, and named pictures the AI can place where they fit), then build. Every page is made one at a time as a draft, written by AI when a key is available or as an outline otherwise. Safe to run again.
* New: wp twd-sk build runs the same build from the command line, with a dry run.
* The site report now shows the setup state and what the last build did.

= 0.7.0 =
* New: therapy or business mode. One switch for administrators (Site tab, Site type; or wp twd-sk mode business; or "mode" in a site brief) that changes the wording the editor and the AI use, the facts outline, the page types, the interview prompt and the search engine details (LocalBusiness instead of a therapy practice). Therapy stays the default and its wording is unchanged. Switching never rewrites a page that is already written.
* Safer: the release check now reads the list of plugin files from the plugin itself.

= 0.6.2 =
* New: wp twd-sk doctor, and a Site report in the Site tab. A plain-text report of how the site stands (versions, safe mode, style, front page, the Elementor header and footer templates and their display conditions, which pages use the kit and what is left to fix, which details are filled in, and the pictures with their alt text). It never shows keys, passwords or the contents of your details, so it is safe to paste into a message. It changes nothing.

= 0.6.1 =
* New: the site brief. One JSON file that describes a whole site (details, menu, header and footer, style, practice facts and the pages to create). Copy the interview prompt, run it in a Claude conversation with the therapist, paste the finished file into the Site tab, check what it would do, then apply it. Details already filled in are kept unless you choose to replace them, and pages are created as draft outlines that you can fill with AI one at a time. You can also download the current site as a brief.

= 0.6.0 =
* Changed: a simpler pop-up. The Site tab sections, history and undo, extra options and the external AI route are now closed fold-outs with a one-line summary, and the Edit screen shows only what to change, the preview and one Apply button. Nothing was removed.

= 0.5.3 =
* New: Ask the AI in the Site tab. Describe a change to the header, the footer or the style and the AI suggests values, which are filled into the boxes you already use. Nothing is saved until you press the normal Save buttons, colours always stay easy to read, and phone numbers, emails, addresses and registration lines can never be changed by the AI.

= 0.5.2 =
* New: Practice facts. One master document about the person and their practice, in the Site tab (administrators only, never shown on the site). The AI uses only this and the site details for anything new it writes.
* New: New page from your practice facts (Pages tab). Draft an About, Contact, Home, service or topic page (for example Working with anxiety) or questions and answers page. It is saved as a draft, nothing is published, and anything the facts do not say stays a visible placeholder. Without an AI key it copies a prompt for an external AI instead.
* New: a quick option to update an existing page from the practice facts.

= 0.5.1 =
* Fixed: the header no longer drops your typed menu when the Site name box is empty. It uses the WordPress site title instead. The footer likewise.

= 0.5.0 =
* New: Ask the AI. When the site has an AI key (set in the Articles plugin), the Edit this page tab can change the page for you. Choose the sections to change, or the whole page, say what you want, and see a preview before anything is saved. Sections you did not choose stay exactly as they are.
* New: testimonials and the safety notice are locked. The AI can change their layout but not their words, unless you say you are supplying new wording.
* Changed: the copy and paste way is still there, under "Use an external AI instead", and its button is now "Copy prompt for external AI". With no AI key, the tab looks as before.
* This plugin does not hold an AI key or contact any AI service. It asks the Articles plugin to do that.

= 0.4.1 =
* New: "Edit header" and "Edit footer" buttons. After you click Edit with AI, small buttons appear on the header and footer of the page. Each opens the pop-up on the Site tab at the right box. They appear for administrators only, never for visitors, and only where the kit header and footer are used.
* New: closing the pop-up with unsaved changes (pasted page text, style, site details, header and footer settings, or search details) now asks first. Keep editing, or close and lose the changes. This applies to the Close button, the Escape key and clicking outside the pop-up.

= 0.4.0 =
* New: Site tab for administrators. Switch the style pack, change colours, fonts and corner roundness with a live preview, and reset. Text that would be hard to read is refused.
* New: site details (name, logo, menu, contact lines, footer text, legal links) with a header and a footer, four layouts each, a mobile menu, and two Elementor Theme Builder templates to import. Each uses one shortcode: [twd_header] and [twd_footer].
* New: Home, About and Contact starter pages and a setup command (wp twd-sk setup, or a button in the Site tab). Everything is a visible placeholder and nothing is published.
* New: Search tab. Search title, description, sharing picture, keep out of search, and the page address, with page checks. Works with Yoast SEO, or prints its own tags when there is no SEO plugin.
* New: a plain-text copy of each page so site search and SEO tools can read it, picture sizes and lazy loading, and structured data for the practice and therapist on the front page.
* New: safe mode (define TWD_SK_SAFE_MODE in wp-config, or wp twd-sk safe-mode on) switches the new features off and keeps the 0.3.1 ones working.

= 0.3.1 =
* New: the "TWD Kit Page" page template. Full width, no theme padding, theme header and footer kept (including an Elementor Theme Builder header and footer), no page builder needed for the page body.
* New: Pages tab in the pop-up. New page makes a draft already set up for the kit. This page shows status and template, with Publish and Unpublish (each asks for a confirmation) and "Switch this page to the kit template" for pages that use the [twd_page] shortcode.
* New: publishing is blocked while "must fix" example text remains (example addresses, sample picture names, sample testimonials and so on) unless you tick an explicit override. Example button wording is only a "check" warning and never blocks. Both levels show in the pop-up and in wp twd-sk check.
* Improved: example link wording in the style guide is meaningful, a new rule stops the AI stating policies or registration status without the therapist's wording, and the leftover check covers more sample text.
* The Edit with AI button now shows on every front-end page for editors (the Pages tab works anywhere); the Edit tab still needs a kit page.

= 0.3.0 =
* New: "Edit with AI" on the front end for signed-in editors. A button (bottom left) opens a pop-up: copy the prompt, paste the AI's result, see what the cleaner changed and any leftover example text, preview it on the real page (nothing is saved), then apply it as a new version. Undo and restore from the last 10 versions. Every apply asks where the facts came from and saves the answer with the version.
* New: secure routes under twd-site-kit/v1 (sign-in nonce, edit permission on the page, size limits and rate limits). No AI key and no outbound calls from the site.

= 0.2.6 =
* New: wp twd-sk check <page_id> lists leftover example text. Saving a page warns about it (nothing is removed).
* Improved: the client AI prompt (image, alt text, heading order, link text, no outcome promises, helplines untouched; examples printed once).

= 0.2.5 =
* New: wp twd-sk prompt <page_id> prints the client AI prompt (rules, style guide, the page's HTML).
* New: loose content directly in a page gets a safe width and side padding. Loose text is wrapped in a paragraph. [PLACEHOLDER] text is kept.

= 0.2.4 =
* New: the resources component styles the articles plugin's grid from the active pack (heading font and title colour on card titles, accent on Read more, body font at 14px or more). No effect when the articles plugin is absent.

= 0.2.3 =
* Fix: body copy at least 16px, eyebrows, small text and buttons at least 14px. Text on bands and buttons reaches 4.5:1 contrast in both packs.

= 0.2.2 =
* Fix: image and text, text with aside and split layouts now share the full container width with fractional columns; the narrow text layout is one centred column.

= 0.2.1 =
* New: self-hosted updater with a checksum check. A "Check for updates" link on the Plugins screen row.

= 0.2.0 =
* New: the one-h1 rule and theme title hiding, eleven components with variants, component styles, style packs, bundled fonts, and the component gallery.

= 0.1.0 =
* First release: page store with version history, the sanitiser, the [twd_page] shortcode and WP-CLI commands.
